BeeChat Store APK build package

Website: https://klay91680-glitch.github.io/beechatstore/

IMPORTANT: Extract this ZIP first. Upload the CONTENTS of the extracted folder to the ROOT of your GitHub repository, not the outer folder itself. Make sure the .github/workflows/build-apk.yml file is included at repository root.

Build:
1. GitHub repository -> Add file -> Upload files.
2. Upload all extracted contents, including the .github folder, app folder, settings.gradle.kts, build.gradle.kts, and gradle.properties.
3. Commit changes.
4. Open the repository's Actions tab.
5. Select "Build BeeChat Store APK" -> "Run workflow" (if available; the push may start it automatically).
6. When successful, open the run and download the BeeChatStore-debug-APK artifact.

The generated APK is debug-signed for testing. For a release build, use your own private signing key and keep it safe. This project has not been compiled or tested on physical devices in this environment. No APK is included in this ZIP. Website-side bugs, server issues, and different Android WebView versions can still cause errors.
